<?php

  class MyDate {

    public static function diff($start, $end) {

      // Sample object:
      return (object)array(
        'years' => null,
        'months' => null,
        'days' => null,
        'total_days' => null,
        'invert' => null
      );

    }

  }
